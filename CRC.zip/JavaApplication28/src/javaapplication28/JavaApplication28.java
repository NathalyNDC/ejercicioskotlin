
package javaapplication28;
import javax.swing.*;

public class JavaApplication28 {
    public static void main(String[] args) {
        CRC a=new CRC();
        int opc=0;
        
        while(opc!=4){
            try {
                opc=Integer.parseInt(JOptionPane.showInputDialog(null,"Opcion:\n1.Dividir\n2.Calcular normal\n3.Receptor\n4.Salir"));
            
               switch(opc){ 
                case 1:
                    divisor("1101");
                break;
                case 2:
                   a.calcular();
                break;
                case 3:
                   a.compr("",JOptionPane.showInputDialog(null,"Ingresa la cadena del receptor:").trim(),"1101");
            } 
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"ELIGE UNA OPCION");
            }
            
        }
        
        
    }
    public static void divisor(String divisor){
        String dividendo=JOptionPane.showInputDialog(null,"Ingresa el dividendo: ");
        int cont=0;
        for(int i=0;i<dividendo.length();i++){
             if(dividendo.substring(i, i+1).equals("0") || dividendo.substring(i, i+1).equals("1")){
                System.out.print(dividendo.substring(i, i+1));//*****
                cont++;
             }
        }
        if (cont!=dividendo.length()) {
              JOptionPane.showMessageDialog(null, "Numero Invalido");
        }
        else{
            String dividendoA=dividendo.concat("000");
            System.out.println("\n"+dividendoA);//*****
            int a=Integer.parseInt(dividendoA,2);
            int b=Integer.parseInt(divisor,2);
            System.out.println(a);
            System.out.println(b);
            int c=a%b;
            String resultado=Integer.toString(c,2);
            String R=String.valueOf(resultado);
            if(R.length()<3){
                if(R.length()==1)
                    R="00".concat(R);
                else
                    R="0".concat(R);
            }
            R=R.substring(R.length()-3);
            JOptionPane.showMessageDialog(null,"El CRC es: "+ R);
            comprobacion(R,dividendo,divisor);
         }
    }
    public static void comprobacion(String R, String dividendo, String divisor){
        dividendo=dividendo.concat(R);
        int a=Integer.parseInt(dividendo,2);
        int b=Integer.parseInt(divisor,2);
        int c=a%b;
        String resultado=Integer.toString(c,2);
        R=String.valueOf(resultado);
        if(R.length()<3){
            if(R.length()==1)
                R="00".concat(R);
            else
                R="0".concat(R);
        }
        R=R.substring(R.length()-3);
        if(R.equals("000"))
            JOptionPane.showMessageDialog(null,"La cadena es: CORRECTA");
        else
            JOptionPane.showMessageDialog(null,"La cadena es: INCORRECTA");
          
    }
}
