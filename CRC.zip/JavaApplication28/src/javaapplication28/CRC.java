package javaapplication28;

import javax.swing.*;

public class CRC {

    public void calcular() {
        String divisor = "1101";
        String dividendo = JOptionPane.showInputDialog(null, "Ingresa el dividendo: ").trim();
        int cont = 0;
        for (int i = 0; i < dividendo.length(); i++) {
            if (dividendo.substring(i, i + 1).equals("0") || dividendo.substring(i, i + 1).equals("1")) {
                System.out.print(dividendo.substring(i, i + 1));//*****
                cont++;
            }
        }
        if (cont != dividendo.length()) {
            JOptionPane.showMessageDialog(null, "Numero Invalido");
        } else {
            String enviar = dividendo;
            dividendo = dividendo.concat("000");
            System.out.println("\n" + dividendo);
            String diga = "";
            String digb = "";
            String opcion = "0000";
            String dividendoO = dividendo;
            for (int j = 4; j <= dividendoO.length(); j++) {
                if (dividendo.substring(0, 1).equals("0")) {
                    divisor = opcion;
                } else {
                    divisor = "1101";
                }
                String nuevDividendo = "";
                for (int i = 0; i < 4; i++) {
                    diga = dividendo.substring(i, i + 1);
                    digb = divisor.substring(i, i + 1);
                    if (diga.equals(digb)) {
                        nuevDividendo = nuevDividendo.concat("0");
                    } else {
                        nuevDividendo = nuevDividendo.concat("1");
                    }
                }
                if(j!=dividendoO.length())
                    dividendo = nuevDividendo.substring(1).concat(dividendoO.substring(j, j + 1));
                else
                    dividendo = nuevDividendo.substring(1);
                System.out.println(dividendo);
            }
            if (dividendo.length() < 3) {
                if (dividendo.length() == 1) {
                    dividendo = "00".concat(dividendo);
                } else {
                    dividendo = "0".concat(dividendo);
                }
            }
            dividendo = dividendo.substring(dividendo.length() - 3);
            JOptionPane.showMessageDialog(null, "El CRC es: " + dividendo);
            compr(enviar, dividendo, divisor);
        }
    }

    public void compr(String om, String dividendo, String divisor) {
        int cont = 0;
        for (int i = 0; i < dividendo.length(); i++) {
            if (dividendo.substring(i, i + 1).equals("0") || dividendo.substring(i, i + 1).equals("1")) {
                System.out.print(dividendo.substring(i, i + 1));//*****
                cont++;
            }
        }
        if (cont != dividendo.length()) {
            JOptionPane.showMessageDialog(null, "Numero Invalido");
        } else {
            System.out.println("\n");
            String dividendoO = om.concat(dividendo);
            String diga = "";
            String digb = "";
            String opcion = "0000";
            dividendo = dividendoO.substring(0, 4);
            for (int j = 4; j <= dividendoO.length(); j++) {
                if (dividendo.substring(0, 1).equals("0")) {
                    divisor = opcion;
                } else {
                    divisor = "1101";
                }
                String nuevDividendo = "";
                for (int i = 0; i < 4; i++) {
                    diga = dividendo.substring(i, i + 1);
                    digb = divisor.substring(i, i + 1);
                    if (diga.equals(digb)) {
                        nuevDividendo = nuevDividendo.concat("0");
                    } else {
                        nuevDividendo = nuevDividendo.concat("1");
                    }
                }
               if(j!=dividendoO.length())
                    dividendo = nuevDividendo.substring(1).concat(dividendoO.substring(j, j + 1));
                else
                    dividendo = nuevDividendo.substring(1);
                System.out.println(dividendo);
            }
            if (dividendo.length() < 3) {
                if (dividendo.length() == 1) {
                    dividendo = "00".concat(dividendo);
                } else {
                    dividendo = "0".concat(dividendo);
                }
            }
            dividendo = dividendo.substring(dividendo.length() - 3);
            if (dividendo.equals("000")) {
                JOptionPane.showMessageDialog(null, "La cadena es: CORRECTA");
            } else {
                JOptionPane.showMessageDialog(null, "La cadena es: INCORRECTA");
            }
        }
    }
}
